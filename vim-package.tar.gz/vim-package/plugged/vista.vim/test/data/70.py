class Foo:
    class Bar:
        def baz(self):
            pass
