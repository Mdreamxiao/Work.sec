# CHANGELOG

- Change `t:vista` to `g:vista` as `t:vista` causes too many issues and I don't have time to make it work as initially designed. #269
